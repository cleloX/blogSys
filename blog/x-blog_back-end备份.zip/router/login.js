const express = require('express');
const login = express.Router();
const conn = require('../conn/mysql');
const session = require('express-session');
login.all('*', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With,Content-Type");
  res.header("Access-Control-Allow-Methods","PUT,POST,GET,DELETE,OPTIONS");
  next();
});
login.post('/', function(req, res) {
    var userName = req.body.loginName;
    var userPwd = req.body.password;
	// console.log(req.headers.cookie);
    // 构建sql语句查询数据库.
    const sql = 'select * from userinfo where pwd=? and name=? or email=? ';
    // const sql = 'select * from userinfo where name=? and pwd=?';
    conn.query(sql, [userPwd,userName,userName], function(err, result) {
      // console.log(result.length);
      // console.log('err：',err,'----','result',result)
        if (err) {
          // res.send({ msg: err, flag: 'no' });
            console.log(err,'======')
            res.send({ msg: '数据查询错误!!', flag: 'no' });
        } else {
            if (result.length !== 1) {
                res.send({ msg: '帐号或者密码错误!!', flag: 'no' });
            } else {
              // console.log('login', result)
              if(result[0].status === 1){
                // session对象，可以将用户登录成功的信息存储到这个对象中，
                // 那么该对象中的数据会存储在服务器内存中。这样我们可以在任何的方法中获取该对象中的数据。注意：由于session中的数据存储在服务器内存中，所以在服务器重新启动后，session中的数据将丢失。
                // req.session.userId = result[0].id;
                let USER = result[0].name + '_' + result[0].id;
                // let USER = 
								req.session[USER] = {
									id:result[0].id,
									name:result[0].name
                }
                console.log( req.session);
                // console.log(result[0].id)
                res.cookie('userId', result[0].id)
                res.cookie('userName', result[0].name)
                res.send({ msg: '恭喜登录成功了!!', flag: 'yes' });
              }else{
                res.send({ msg: '您已被限制登录，请联系管理员！', flag: 'no' });
              }
            }
        }
    })
    
})



module.exports = login