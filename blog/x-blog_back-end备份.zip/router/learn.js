const express = require('express');
const learn = express.Router();
const conn = require('../conn/mysql')
learn.all('*', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With,Content-Type");
  res.header("Access-Control-Allow-Methods","PUT,POST,GET,DELETE,OPTIONS");
  next();
});

learn.post('/', (req, res) => {

  let {search, cla} = req.body
  let sql;
  if(!search){
    if(cla == 'all'){
      sql = 'select * from user_article'
    }else{
      sql = `select * from user_article where classifacation=${cla}`
    }
  }else{
    if(cla == 'all'){
      sql = `SELECT * from user_article  WHERE title LIKE '%${search}' or author like '%${search}'`
    }else{
      sql = sql = `SELECT * from user_article  WHERE title LIKE '%${search}' or author like '%${search}' and classifacation=${cla}`
    }
    
  }
  
  conn.query(sql, [], (err,result) => {
    if (err) {
      console.log(err)
      res.send(err)
    } else{
      console.log(result)
      res.send({msg:'检索成功！', list:result})
	  
    }
  })
  // res.send('response' )
});


learn.post('/userPublish', (req, res) => {
  // console.log(req.body+';'+'app.js:43');
  // console.log(req.body);
  let postData = {title, content, classifacation, time, author} = req.body
  let data = []
  // for (let i in postData){
  //   data.push(postData[i])
  // }
  Object.keys(postData).forEach((key) => {
    data.push(postData[key])
  })
  // console.log(data);
  let sql = 'insert into user_article(title,content,classifacation,time,author) value(?,?,?,?,?)'
  conn.query(sql, data, (err,result) => {
    if (err) {
      console.log(err)
      res.send(err)
    } else{

      res.send({msg:'发布文章成功！'})
	  
    }
  })
  // res.send('response' )
});



module.exports = learn