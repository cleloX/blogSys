const express = require('express');
const admin = express.Router();
const conn = require('../../conn/mysql')
admin.all('*', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With,Content-Type");
  res.header("Access-Control-Allow-Methods","PUT,POST,GET,DELETE,OPTIONS");
  next();
});
admin.post('/login', function(req, res) {
  // console.log('11')
    var userName = req.body.loginName;
    var userPwd = req.body.password;
	// console.log(req.headers.cookie);
    // 构建sql语句查询数据库.
    const sql = 'select * from userinfo where name=? or id=? or email=? and pwd=?';
    // const sql = 'select * from userinfo where name=? and pwd=?';
    conn.query(sql, [userName, userName, userName, userPwd], function(err, result) {
      // console.log(result.length);
      // console.log('err：',err,'----','result',result)
        if (err) {
          // res.send({ msg: err, flag: 'no' });
            // console.log(err,'======')
            res.send({ msg: '数据查询错误!!', flag: 'no' });
        } else {
            if (result.length !== 1) {
                res.send({ msg: '帐号或者密码错误!!', flag: 'no' });
            } else {
              if(result[0].status === 1){
                // session对象，可以将用户登录成功的信息存储到这个对象中，
                // 那么该对象中的数据会存储在服务器内存中。这样我们可以在任何的方法中获取该对象中的数据。注意：由于session中的数据存储在服务器内存中，所以在服务器重新启动后，session中的数据将丢失。
                // req.session.userId = result[0].id;
								let USER = 'admin';
								req.session[USER] = {
									name:result[0].name
								}
								// console.log( req.session);
								res.cookie('userId', result[0].id)
                res.send({ msg: '恭喜登录成功了!!', flag: 'yes' });
              }else{
                res.send({ msg: '您已被限制登录，请联系管理员！', flag: 'no' });
              }
            }
        }
    })
})
//获取用户列表
admin.get('/getUserList',(req, res) => {
  const sql = 'select * from userinfo'
  conn.query(sql, {}, (err,result) =>{
    // console.log(coment(result[0].time).format('YYYY-MM-DD HH:mm:ss'));
    // console.log(coment().format('YYYY-MM-DD HH:mm:ss'));
    if (err){
      console.log('getUserList  err:',err);
    } else{
      // console.log(result);
      
      res.json({
       list:result

      })
    }
  })

})


//修改用户信息
admin.post('/updataUserMsg',(req, res) => {
  let {id, name, email, pwd, role, status} = req.body
  const sql = 'update userinfo set name=?, email=?, pwd=?, role=?, status=? where id=?'
  conn.query(sql, [name,email,pwd,role,status,id], (err,result) =>{
    // console.log(coment(result[0].time).format('YYYY-MM-DD HH:mm:ss'));
    // console.log(coment().format('YYYY-MM-DD HH:mm:ss'));
    if (err){
      console.log('updataUserMsg err:',err);
      res.send({msg:'修改失败！', err:err})
    } else{
      // console.log(result);
      res.send({msg:'修改成功！'})
    }
  })

})

//删除用户信息
admin.post('/delUser',(req, res) => {
  let {id} = req.body
  const sql = 'DELETE FROM userinfo WHERE id=?'
  conn.query(sql, [id], (err,result) =>{
    // console.log(coment(result[0].time).format('YYYY-MM-DD HH:mm:ss'));
    // console.log(coment().format('YYYY-MM-DD HH:mm:ss'));
    if (err){
      console.log('updataUserMsg err:',err);
      res.send({msg:'删除失败！', err:err})
    } else{
      // console.log(result);
      res.send({msg:'删除成功！'})
    }
  })

})


//删除文章
admin.post('/delArticle',(req, res) => {
  let {id, tableName} = req.body
  const sql = `DELETE FROM ${tableName} WHERE article_id=?`
  conn.query(sql, [id], (err,result) =>{
    // console.log(coment(result[0].time).format('YYYY-MM-DD HH:mm:ss'));
    // console.log(coment().format('YYYY-MM-DD HH:mm:ss'));
    if (err){
      console.log('delArticle err:',err);
      res.send({msg:'删除失败！', err:err})
    } else{
      // console.log(result);
      res.send({msg:'删除成功！'})
    }
  })

})

module.exports = admin