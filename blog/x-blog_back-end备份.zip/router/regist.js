const express = require('express');
const regist = express.Router();
const conn = require('../conn/mysql')
regist.all('*', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With,Content-Type");
  res.header("Access-Control-Allow-Methods","PUT,POST,GET,DELETE,OPTIONS");
  next();
});
regist.post('/', function(req, res) {
  let userName = req.body.userName;
  let userEmail = req.body.userEmail;
  let userPassword = req.body.userPassword;
  const sql1 = `select * from userinfo where name=? or email=?`;
  conn.query(sql1, [userName, userEmail], function(err, result) {
    if(err){
      res.send({msg:err, flag:0})
    }else{

      if(result.length >= 1){
        res.send({isRegisted:1})
      }else{
        const sql = 'INSERT INTO userinfo(name,email,pwd,role,status) VALUES(?,?,?,?,?)';

        conn.query(sql, [userName,userEmail,userPassword,'normal',1], function(err, result) {
          if(err){
            console.log(err)
            res.send({msg:'注册失败！', flag:0})
          }else{
            res.send({msg:'注册成功！', flag:1})
          }
        })
      }
    }
  })
  
	// console.log(req.session.current);
	// res.cookie('login', 0)
  // res.send('regist success!')
})

regist.post('/check', (req, res) =>{
  let userName = req.body.userName;
  let userEmail = req.body.userEmail;
  let check
  if(req.body.checkW === 'name'){
    check = userName
  }else{
    check = userEmail
  }
  // console.log(req.body.checkW)
  const sql = `select * from userinfo where ${req.body.checkW}=?`;

  conn.query(sql, [check], function(err, result) {
    if(err){
      res.send({msg:err, flag:0})
    }else{
      // console.log(result.length)
      if(result.length >= 1){
        res.send({isRegisted:1})
      }else{
        res.send({isRegisted:0})
      }
    }
  })
})



module.exports = regist