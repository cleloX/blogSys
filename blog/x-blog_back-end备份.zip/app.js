const path = require('path')
const fs = require('fs')
//1//导入需要使用的模块（先安装）
//express框架
const express = require('express')
//处理post请求的数据
const bodyParser = require('body-parser')

//链接mysql数据库
const mysql = require('mysql')
//用于处理session
const session = require('express-session')
const { createProxyMiddleware } = require('http-proxy-middleware');



const app = express()
//在其他路由中间件前（尽可能靠前，以能够通过bodyParser获取req.body）
//(不加 可能无法获取到参数)
app.use(bodyParser.json())
// 注册解析表单数据的bodyParser
app.use(bodyParser.urlencoded({ extended: false}))
//设置静态资源
app.use(express.static(path.resolve(__dirname, './dist')))
// 你就可以通过带有 /image 前缀地址来访问 public 目录中的文件了。
app.use('/image', express.static(path.join(__dirname, './public')))
// app.use('/api', createProxyMiddleware({ target: 'http://localhost:8000', changeOrigin: true }));
app.use(
  session({
	name:'session',
    secret: '密钥',
    resave: false,
    saveUninitialized: false,
	cookie:{
		maxAge:1000*60*60*24*1
	}
  })
)

//引入数据库链接
let conn = require('./conn/mysql');
// 连接云端的MySQL数据库发现连接成功后，一直保持连接不使用end（）等断开，发现2分钟后刷新页面重新发送查询命令会超时无效
// function handleError () {
//   //创建一个mysql连接对象
//    conn =  require('./conn/mysql')
//    setTimeout(handleError , 60000*2);
//    //连接错误，2秒重试
//    conn.connect(function (err) {
//        if (err) {
//            console.log('error when connecting to db:', err);
//            setTimeout(handleError , 2000);
//        }
//    });
//    //监听错误
//    conn.on('error', function (err) {
//        console.log('db error', err);
//        // 如果是连接断开，自动重新连接
//        if (err.code === 'PROTOCOL_CONNECTION_LOST') {
//            handleError();
//        } else {
//            throw err;
//        }
//    });
// }
// handleError();


//解决跨域
app.all('*', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With,Content-Type");
  res.header("Access-Control-Allow-Methods","PUT,POST,GET,DELETE,OPTIONS");
  next();
});
const home = require('./router/home')
const learn = require('./router/learn')
const test = require('./router/test')
const login = require('./router/login')
const regist = require('./router/regist')
const admin = require('./router/admin/admin')
//请求拦截，为路由请求匹配路径（当一级路由参数为home时，直接去一级路由admin对象里面）
app.use('/home',home);
app.use('/learn',learn);
app.use('/test',test);
app.use('/login',login)
app.use('/regist',regist)
app.use('/admin',admin)



app.post('/publishArticle', (req, res) => {
  // console.log(req.body+';'+'app.js:43');
  // console.log(req.body);
  let postData = {title, content, classifacation, time} = req.body
  let data = []
  // for (let i in postData){
  //   data.push(postData[i])
  // }
  Object.keys(postData).forEach((key) => {
    data.push(postData[key])
  })
  // console.log(data);
  let sql = 'insert into article(title,content,classifacation,time) value(?,?,?,?)'
  conn.query(sql, data, (err,result) => {
    if (err) {
      console.log(err)
      res.send(err)
    } else{
      // console.log(result)
	  // res.cookie('isFirst', 1, { maxAge: 5000, singed: true});
	  //   res.cookie('isFirst2', 2, { maxAge: 5000, singed: true});
	  req.session.current = '插入信息'
			// console.log(req.session);
      res.send('插入成功')
	  
    }
  })
  // res.send('response' )
});


app.post('/upLoad', require('./router/uploads/upload'))
app.get('/getfiles',(req, res) => {
  const sql = 'select * from upload_files'
  conn.query(sql, {}, (err,result) =>{
    // console.log(coment(result[0].time).format('YYYY-MM-DD HH:mm:ss'));
    // console.log(coment().format('YYYY-MM-DD HH:mm:ss'));
    if (err){
      console.log('getfiles  err:',err);
    } else{
      // console.log(result);
      
      res.json({
       list:result

      })
    }
  })
})
//删除用户信息
app.post('/delfiles',(req, res) => {
  let {file_id} = req.body
  // console.log(file_id)
  const sql = 'DELETE FROM upload_files WHERE file_id=?'
  conn.query(sql, [file_id], (err,result) =>{
    // console.log(coment(result[0].time).format('YYYY-MM-DD HH:mm:ss'));
    // console.log(coment().format('YYYY-MM-DD HH:mm:ss'));
    if (err){
      console.log('delfiles err:',err);
      res.send({msg:'删除失败！', err:err})
    } else{
      // console.log(result);
      res.send({msg:'删除成功！'})
    }
  })

})

app.get('/image/1', (req, res) => {
	res.sendFile(__dirname + '/public/uploads' + '/upload_2ccb4fc2cccd62a2178361383e524d1f.png')
})


app.get('*', function(req, res) {
  const html = fs.readFileSync(path.resolve(__dirname, './dist/index.html'), 'utf-8')
  res.send(html)
})




app.listen(8081, function() {
  console.log('server running..........');
})
